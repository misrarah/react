import { useState } from "react";

// ─── Demo registry — add new spikes here ─────────────────────────────────────
const SPIKES = [
  {
    id: "databar-calibration",
    title: "Databar Calibration",
    subtitle: "AG-Grid · UI Component",
    description: "Right-click column header to recalibrate databar min/mid/max. Supports diverging, LTR and RTL bar modes, outlier-aware IQR range suggestions, and a sign-preserving logarithmic scale.",
    tags: ["ag-grid", "data-viz", "ux"],
    status: "live",
    date: "Mar 2026",
    path: "/databar-calibration",
    accent: "#22d3ee",
    preview: (
      <div style={{ display: "flex", flexDirection: "column", gap: 5, padding: "4px 0" }}>
        {[105, 44, -42, 78, -85, 27].map((v, i) => {
          const pct = Math.max(0, Math.min(100, ((v + 120) / 240) * 100));
          const mid = 50;
          const isPos = v >= 0;
          return (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ width: 28, textAlign: "right", fontSize: 9, color: "#475569", fontFamily: "monospace" }}>{v}</span>
              <div style={{ flex: 1, height: 8, background: "#0f172a", borderRadius: 1, position: "relative", overflow: "hidden" }}>
                <div style={{
                  position: "absolute", top: 0, height: "100%",
                  background: isPos ? "#22d3ee" : "#f472b8",
                  left: isPos ? `${mid}%` : `${pct}%`,
                  width: isPos ? `${pct - mid}%` : `${mid - pct}%`,
                  opacity: 0.8,
                }} />
                <div style={{ position: "absolute", top: 0, bottom: 0, left: "50%", width: 1, background: "#1e293b" }} />
              </div>
            </div>
          );
        })}
      </div>
    ),
  },
  {
    id: "placeholder-1",
    title: "Coming Soon",
    subtitle: "Next Spike",
    description: "Drop your next prototype here. Edit the SPIKES array in SpikeLab.jsx to add a new card with its own accent colour, tags, preview thumbnail and route.",
    tags: ["tbd"],
    status: "wip",
    date: "—",
    path: null,
    accent: "#94a3b8",
    preview: (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 70, opacity: 0.2 }}>
        <span style={{ fontSize: 32, color: "#475569" }}>＋</span>
      </div>
    ),
  },
];

const TAG_COLORS = {
  "ag-grid":   { bg: "#0e3a4a", text: "#67e8f9", border: "#164e63" },
  "data-viz":  { bg: "#1a0e3a", text: "#c4b5fd", border: "#2e1065" },
  "ux":        { bg: "#0f2a0e", text: "#86efac", border: "#14532d" },
  "tbd":       { bg: "#1e293b", text: "#475569", border: "#334155" },
};

// ─── Animated grid bg ─────────────────────────────────────────────────────────
const GridBg = () => (
  <div style={{
    position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
    backgroundImage: `
      linear-gradient(rgba(34,211,238,0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(34,211,238,0.03) 1px, transparent 1px)
    `,
    backgroundSize: "48px 48px",
  }} />
);

// ─── Noise overlay ────────────────────────────────────────────────────────────
const NoiseOverlay = () => (
  <div style={{
    position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", opacity: 0.025,
    backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
    backgroundRepeat: "repeat",
    backgroundSize: "128px 128px",
  }} />
);

// ─── Spike Card ───────────────────────────────────────────────────────────────
function SpikeCard({ spike, index }) {
  const [hovered, setHovered] = useState(false);
  const isLive = spike.status === "live";

  return (
    <a
      href={spike.path || undefined}
      onClick={!spike.path ? e => e.preventDefault() : undefined}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "block",
        textDecoration: "none",
        cursor: isLive ? "pointer" : "default",
        animation: `fadeUp 0.4s ease both`,
        animationDelay: `${index * 0.08}s`,
      }}
    >
      <div style={{
        background: hovered && isLive ? "#0d1520" : "#0a0f1a",
        border: `1px solid ${hovered && isLive ? spike.accent + "55" : "#1e293b"}`,
        borderRadius: 12,
        padding: "22px 22px 18px",
        transition: "all 0.2s ease",
        boxShadow: hovered && isLive ? `0 0 0 1px ${spike.accent}22, 0 12px 40px rgba(0,0,0,0.4)` : "none",
        position: "relative",
        overflow: "hidden",
      }}>
        {/* Accent glow top edge */}
        {isLive && (
          <div style={{
            position: "absolute", top: 0, left: 0, right: 0, height: 1,
            background: `linear-gradient(90deg, transparent, ${spike.accent}88, transparent)`,
            opacity: hovered ? 1 : 0,
            transition: "opacity 0.2s",
          }} />
        )}

        {/* Header row */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
              <span style={{
                fontSize: 15, fontWeight: 700, color: hovered && isLive ? spike.accent : "#e2e8f0",
                fontFamily: "'Syne', sans-serif", transition: "color 0.2s", letterSpacing: "-0.01em",
              }}>{spike.title}</span>
              {/* Status dot */}
              <span style={{
                width: 6, height: 6, borderRadius: "50%",
                background: isLive ? "#22c55e" : "#475569",
                flexShrink: 0,
                boxShadow: isLive ? "0 0 6px #22c55e" : "none",
              }} />
            </div>
            <div style={{ fontSize: 10, color: "#334155", fontFamily: "'DM Mono', monospace", letterSpacing: "0.06em" }}>
              {spike.subtitle}
            </div>
          </div>
          <div style={{ fontSize: 10, color: "#1e293b", fontFamily: "'DM Mono', monospace", textAlign: "right" }}>
            {spike.date}
          </div>
        </div>

        {/* Preview area */}
        <div style={{
          background: "#060a10", borderRadius: 7, padding: "10px 12px", marginBottom: 14,
          border: "1px solid #0f172a", minHeight: 80,
        }}>
          {spike.preview}
        </div>

        {/* Description */}
        <p style={{
          margin: "0 0 14px", fontSize: 12, color: "#475569", lineHeight: 1.6,
          fontFamily: "'DM Sans', sans-serif",
        }}>{spike.description}</p>

        {/* Footer: tags + arrow */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
            {spike.tags.map(tag => {
              const c = TAG_COLORS[tag] || TAG_COLORS["tbd"];
              return (
                <span key={tag} style={{
                  fontSize: 9, padding: "2px 7px", borderRadius: 3,
                  background: c.bg, color: c.text, border: `1px solid ${c.border}`,
                  fontFamily: "'DM Mono', monospace", letterSpacing: "0.05em",
                }}>#{tag}</span>
              );
            })}
          </div>
          {isLive && (
            <span style={{
              fontSize: 11, color: hovered ? spike.accent : "#334155",
              fontFamily: "'DM Mono', monospace", transition: "color 0.2s",
              transform: hovered ? "translateX(3px)" : "translateX(0)",
              display: "inline-block", transition: "color 0.2s, transform 0.2s",
            }}>→</span>
          )}
        </div>
      </div>
    </a>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function SpikeLab() {
  const [filter, setFilter] = useState("all");

  const allTags = ["all", ...Array.from(new Set(SPIKES.flatMap(s => s.tags).filter(t => t !== "tbd")))];
  const filtered = filter === "all" ? SPIKES : SPIKES.filter(s => s.tags.includes(filter));

  return (
    <div style={{ minHeight: "100vh", background: "#060a10", color: "#e2e8f0", position: "relative" }}>
      <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@400;500&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(16px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50%       { opacity: 0.4; }
        }
        * { box-sizing: border-box; }
        a { color: inherit; }
        input[type=number]::-webkit-inner-spin-button { -webkit-appearance: none; }
      `}</style>

      <GridBg />
      <NoiseOverlay />

      {/* Radial glow */}
      <div style={{
        position: "fixed", top: -200, left: "50%", transform: "translateX(-50%)",
        width: 800, height: 400,
        background: "radial-gradient(ellipse, rgba(34,211,238,0.06) 0%, transparent 70%)",
        pointerEvents: "none", zIndex: 0,
      }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: 960, margin: "0 auto", padding: "60px 24px 80px" }}>

        {/* Header */}
        <div style={{ marginBottom: 56, animation: "fadeUp 0.5s ease both" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
            <div style={{ display: "flex", gap: 5 }}>
              {["#22d3ee", "#f472b8", "#a78bfa"].map((c, i) => (
                <div key={i} style={{ width: 8, height: 8, borderRadius: "50%", background: c, boxShadow: `0 0 8px ${c}` }} />
              ))}
            </div>
            <span style={{ fontSize: 10, color: "#334155", fontFamily: "'DM Mono', monospace", letterSpacing: "0.1em" }}>SPIKE LAB</span>
          </div>

          <h1 style={{
            margin: 0, fontSize: "clamp(36px, 6vw, 64px)", fontWeight: 800,
            fontFamily: "'Syne', sans-serif", lineHeight: 1.05, letterSpacing: "-0.03em",
            color: "#f1f5f9",
          }}>
            Prototypes &<br />
            <span style={{ color: "#22d3ee" }}>Experiments</span>
          </h1>

          <p style={{
            margin: "16px 0 0", fontSize: 15, color: "#475569", maxWidth: 480,
            lineHeight: 1.7, fontFamily: "'DM Sans', sans-serif",
          }}>
            A running catalogue of UI spikes, component explorations and design experiments.
            Each demo is self-contained and built to be forked.
          </p>
        </div>

        {/* Filter bar */}
        <div style={{ display: "flex", gap: 6, marginBottom: 36, flexWrap: "wrap", animation: "fadeUp 0.5s ease 0.1s both" }}>
          {allTags.map(tag => (
            <button key={tag} onClick={() => setFilter(tag)} style={{
              padding: "5px 13px", borderRadius: 20, border: "none", cursor: "pointer",
              background: filter === tag ? "#22d3ee" : "#0f172a",
              color: filter === tag ? "#060a10" : "#475569",
              fontSize: 11, fontWeight: filter === tag ? 600 : 400,
              fontFamily: "'DM Mono', monospace", letterSpacing: "0.04em",
              border: `1px solid ${filter === tag ? "#22d3ee" : "#1e293b"}`,
              transition: "all 0.15s",
            }}>
              {tag === "all" ? "all" : `#${tag}`}
            </button>
          ))}
        </div>

        {/* Cards grid */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: 16,
        }}>
          {filtered.map((spike, i) => (
            <SpikeCard key={spike.id} spike={spike} index={i} />
          ))}
        </div>

        {/* Footer */}
        <div style={{
          marginTop: 72, paddingTop: 24, borderTop: "1px solid #0f172a",
          display: "flex", justifyContent: "space-between", alignItems: "center",
          flexWrap: "wrap", gap: 12,
          animation: "fadeUp 0.5s ease 0.3s both",
        }}>
          <span style={{ fontSize: 11, color: "#1e293b", fontFamily: "'DM Mono', monospace" }}>
            Add new demos by editing the SPIKES array in SpikeLab.jsx
          </span>
          <div style={{ display: "flex", gap: 16 }}>
            {[
              { label: "Live", color: "#22c55e" },
              { label: "WIP",  color: "#475569" },
            ].map(({ label, color }) => (
              <div key={label} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: color, boxShadow: color === "#22c55e" ? "0 0 6px #22c55e" : "none" }} />
                <span style={{ fontSize: 10, color: "#334155", fontFamily: "'DM Mono', monospace" }}>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
