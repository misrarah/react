# Spike Lab

A landing page for hosting UI prototypes and demos.

## Setup

```bash
npm create vite@latest spike-lab -- --template react
cd spike-lab
npm install react-router-dom
```

Copy these files into `src/`:
- `SpikeLab.jsx`         — landing page
- `main.jsx`             — router entry (replace the existing one)
- `databar-calibration-v2.jsx` — databar demo

Then run:
```bash
npm run dev
```

---

## Adding a new spike

**1. Drop your component into `src/`**
e.g. `src/MyNewSpike.jsx` with a default export.

**2. Add a route in `main.jsx`**
```jsx
import MyNewSpike from "./MyNewSpike";

<Route path="/my-new-spike" element={<MyNewSpike />} />
```

**3. Add a card in `SpikeLab.jsx`**

Find the `SPIKES` array at the top and add an entry:
```js
{
  id: "my-new-spike",
  title: "My New Spike",
  subtitle: "Category · Type",
  description: "What it does and why it's interesting.",
  tags: ["ux", "data-viz"],   // drives the filter bar
  status: "live",              // "live" | "wip"
  date: "Mar 2026",
  path: "/my-new-spike",       // matches the route above
  accent: "#f472b8",           // card hover colour
  preview: (
    // small JSX thumbnail shown in the card — keep it lightweight
    <div style={{ color: "#475569", fontSize: 11 }}>Preview here</div>
  ),
},
```

That's it — the card appears on the landing page automatically.

---

## Tag colours

Defined in `TAG_COLORS` in `SpikeLab.jsx`. Add new tags there to give them custom colours.
