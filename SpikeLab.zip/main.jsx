import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SpikeLab from "./SpikeLab";
import DatabarCalibration from "./databar-calibration-v2";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/"                        element={<SpikeLab />} />
        <Route path="/databar-calibration"     element={<DatabarCalibration />} />
        {/* Add new spike routes here */}
      </Routes>
    </BrowserRouter>
  </StrictMode>
);
