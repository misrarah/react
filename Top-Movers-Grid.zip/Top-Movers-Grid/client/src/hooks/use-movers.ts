import { useQuery } from "@tanstack/react-query";
import { api, type MoversListInput } from "@shared/routes";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

function buildQuery(input?: MoversListInput) {
  if (!input) return "";
  const params = new URLSearchParams();
  if (typeof input.limit === "number") params.set("limit", String(input.limit));
  if (input.asOf) params.set("asOf", input.asOf);
  const qs = params.toString();
  return qs ? `?${qs}` : "";
}

export function useMovers(input?: MoversListInput) {
  const qs = buildQuery(input);
  return useQuery({
    queryKey: [api.movers.list.path, qs],
    queryFn: async () => {
      const res = await fetch(`${api.movers.list.path}${qs}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch movers");
      const json = await res.json();
      return parseWithLogging(api.movers.list.responses[200], json, "movers.list");
    },
  });
}
