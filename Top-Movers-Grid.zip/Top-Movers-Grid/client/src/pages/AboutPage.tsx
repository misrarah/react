import React from "react";
import AppShell from "@/components/AppShell";
import GlassCard from "@/components/GlassCard";
import { Grid3X3, SlidersHorizontal, SortDesc } from "lucide-react";

export default function AboutPage() {
  return (
    <AppShell
      title="About"
      subtitle={
        <span>
          A focused grid for scanning LSE movers — designed like a modern terminal: sharp typography, high contrast, and deliberate motion.
        </span>
      }
    >
      <div className="animate-in-soft">
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <GlassCard>
              <h2 className="text-2xl">Design Principles</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                This interface is intentionally restrained: the goal is to surface signal fast, reduce cognitive load,
                and keep interactions crisp.
              </p>

              <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="rounded-3xl border border-border/70 bg-card/25 p-5">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border border-border/70 bg-muted/20">
                    <Grid3X3 className="h-5 w-5 text-primary" />
                  </div>
                  <div className="mt-4 text-lg font-bold">Clarity</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Exactly five columns. No fluff.
                  </div>
                </div>

                <div className="rounded-3xl border border-border/70 bg-card/25 p-5">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border border-border/70 bg-muted/20">
                    <SlidersHorizontal className="h-5 w-5 text-[hsl(var(--accent))]" />
                  </div>
                  <div className="mt-4 text-lg font-bold">Control</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Fast text filters on the fields that matter.
                  </div>
                </div>

                <div className="rounded-3xl border border-border/70 bg-card/25 p-5">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border border-border/70 bg-muted/20">
                    <SortDesc className="h-5 w-5 text-[hsl(var(--chart-3))]" />
                  </div>
                  <div className="mt-4 text-lg font-bold">Signal</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Default ordering by absolute % move.
                  </div>
                </div>
              </div>

              <div className="mt-6 rounded-3xl border border-border/70 bg-muted/10 p-5">
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Notes
                </div>
                <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-muted-foreground">
                  <li>Numeric fields are formatted in the UI (GBP + percent), parsed from string values.</li>
                  <li>Pagination is client-side at 25 rows per page.</li>
                  <li>Row selection is single-click; details appear in the left panel.</li>
                  <li>Grid header is sticky to keep context on scroll.</li>
                </ul>
              </div>
            </GlassCard>
          </div>

          <div className="lg:col-span-5">
            <GlassCard className="h-full">
              <h2 className="text-2xl">Keyboard & Accessibility</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Focus states are explicit, contrast is high, and interactions are designed to feel crisp at 60fps.
              </p>

              <div className="mt-6 space-y-3">
                <div className="rounded-3xl border border-border/70 bg-card/25 p-5">
                  <div className="text-sm font-semibold text-foreground/90">Focus rings</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Every interactive control uses a consistent ring and border change.
                  </div>
                </div>

                <div className="rounded-3xl border border-border/70 bg-card/25 p-5">
                  <div className="text-sm font-semibold text-foreground/90">Tabular numerals</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Numeric columns align cleanly for quick scanning.
                  </div>
                </div>

                <div className="rounded-3xl border border-border/70 bg-card/25 p-5">
                  <div className="text-sm font-semibold text-foreground/90">Responsive layout</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Filters stack on mobile; grid keeps its density on desktop.
                  </div>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
