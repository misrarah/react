import React, { useMemo } from "react";
import AppShell from "@/components/AppShell";
import GlassCard from "@/components/GlassCard";
import { useMovers } from "@/hooks/use-movers";
import MetricPill from "@/components/MetricPill";
import { Activity, ArrowDownRight, ArrowUpRight, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

function parseNum(v: unknown): number {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : 0;
  return Number.isFinite(n) ? n : 0;
}

function formatGBP(n: number) {
  return `£${n.toFixed(2)}`;
}

function formatPct(n: number) {
  const sign = n > 0 ? "+" : n < 0 ? "−" : "";
  return `${sign}${Math.abs(n).toFixed(2)}%`;
}

export default function InsightsPage() {
  const { data, isLoading, error, refetch, isFetching } = useMovers({ limit: 50 });

  const insights = useMemo(() => {
    const stocks = data?.stocks ?? [];
    if (!stocks.length) return null;

    const parsed = stocks.map((s) => ({
      ...s,
      pct: parseNum(s.percentageMove),
      chg: parseNum(s.change),
      price: parseNum(s.price),
    }));

    const topGainer = [...parsed].sort((a, b) => b.pct - a.pct)[0];
    const topLoser = [...parsed].sort((a, b) => a.pct - b.pct)[0];

    const avgMove =
      parsed.reduce((acc, s) => acc + Math.abs(s.pct), 0) / Math.max(1, parsed.length);

    const advancers = parsed.filter((s) => s.pct > 0).length;
    const decliners = parsed.filter((s) => s.pct < 0).length;
    const flat = parsed.length - advancers - decliners;

    return { topGainer, topLoser, avgMove, advancers, decliners, flat, total: parsed.length };
  }, [data?.stocks]);

  return (
    <AppShell
      title="Insights"
      subtitle={
        <span>
          Quick readouts from the current snapshot — not investment advice, just signal.
        </span>
      }
      rightSlot={
        <button
          type="button"
          onClick={() => refetch()}
          data-testid="insights-refresh"
          disabled={isFetching}
          className={cn(
            "inline-flex items-center gap-2 rounded-2xl border px-4 py-2 text-sm font-semibold",
            "bg-card/30 border-border/70 text-foreground",
            "shadow-sm shadow-black/20 transition-all duration-200",
            "hover:-translate-y-0.5 hover:bg-card/50 hover:shadow-lg hover:shadow-black/30",
            "active:translate-y-0 active:shadow-md",
            "focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring",
            "disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none"
          )}
        >
          <Activity className={cn("h-4 w-4", isFetching ? "animate-spin" : "")} />
          Refresh
        </button>
      }
    >
      <div className="animate-in-soft">
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <GlassCard>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-xl">Market Pulse</h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    At-a-glance distribution and volatility.
                  </p>
                </div>
                <div className="grid h-11 w-11 place-items-center rounded-2xl border border-border/70 bg-muted/20">
                  <Sparkles className="h-5 w-5 text-[hsl(var(--accent))]" />
                </div>
              </div>

              {isLoading ? (
                <div className="mt-6 rounded-3xl border border-border/70 bg-card/25 p-6 text-sm text-muted-foreground">
                  Loading insights…
                </div>
              ) : error ? (
                <div className="mt-6 rounded-3xl border border-destructive/40 bg-[rgba(239,68,68,0.07)] p-6 text-sm text-muted-foreground">
                  {String((error as Error).message ?? "Failed to load insights")}
                </div>
              ) : !insights ? (
                <div className="mt-6 rounded-3xl border border-border/70 bg-card/25 p-6 text-sm text-muted-foreground">
                  No data available.
                </div>
              ) : (
                <div className="mt-6 space-y-4">
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <MetricPill
                      data-testid="insights-avg"
                      label="Avg |% Move|"
                      value={formatPct(insights.avgMove)}
                      tone="neutral"
                    />
                    <MetricPill
                      data-testid="insights-total"
                      label="Total"
                      value={`${insights.total}`}
                      tone="neutral"
                    />
                  </div>

                  <div className="rounded-3xl border border-border/70 bg-card/20 p-5">
                    <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      Breadth
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-3">
                      <div className="rounded-2xl border border-border/70 bg-muted/15 p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Advancers
                        </div>
                        <div className="mt-1 text-lg font-bold tabular-nums text-[rgb(16,185,129)]">
                          {insights.advancers}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-border/70 bg-muted/15 p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Flat
                        </div>
                        <div className="mt-1 text-lg font-bold tabular-nums text-[rgb(107,114,128)]">
                          {insights.flat}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-border/70 bg-muted/15 p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Decliners
                        </div>
                        <div className="mt-1 text-lg font-bold tabular-nums text-[rgb(239,68,68)]">
                          {insights.decliners}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </GlassCard>
          </div>

          <div className="lg:col-span-7">
            <GlassCard className="h-full">
              <h2 className="text-xl">Top Extremes</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Biggest winner and loser by percentage move.
              </p>

              {isLoading ? (
                <div className="mt-6 rounded-3xl border border-border/70 bg-card/25 p-6 text-sm text-muted-foreground">
                  Loading snapshot…
                </div>
              ) : error ? (
                <div className="mt-6 rounded-3xl border border-destructive/40 bg-[rgba(239,68,68,0.07)] p-6 text-sm text-muted-foreground">
                  {String((error as Error).message ?? "Failed to load data")}
                </div>
              ) : !insights ? (
                <div className="mt-6 rounded-3xl border border-border/70 bg-card/25 p-6 text-sm text-muted-foreground">
                  No data available.
                </div>
              ) : (
                <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="rounded-3xl border border-[rgba(16,185,129,0.35)] bg-[rgba(16,185,129,0.06)] p-5">
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-semibold uppercase tracking-wider text-[rgba(16,185,129,0.9)]">
                        Top Gainer
                      </div>
                      <div className="grid h-10 w-10 place-items-center rounded-2xl border border-[rgba(16,185,129,0.35)] bg-[rgba(16,185,129,0.10)]">
                        <ArrowUpRight className="h-5 w-5 text-[rgb(16,185,129)]" />
                      </div>
                    </div>
                    <div className="mt-4 text-2xl font-bold">
                      {String(insights.topGainer.ticker).toUpperCase()}
                    </div>
                    <div className="mt-1 text-sm text-muted-foreground">
                      {insights.topGainer.stockName}
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-2">
                      <div className="rounded-2xl border border-border/70 bg-black/20 p-3">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          % Move
                        </div>
                        <div className="mt-1 font-semibold tabular-nums text-[rgb(16,185,129)]">
                          {formatPct(insights.topGainer.pct)}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-border/70 bg-black/20 p-3">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Price
                        </div>
                        <div className="mt-1 font-semibold tabular-nums">
                          {formatGBP(insights.topGainer.price)}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-3xl border border-[rgba(239,68,68,0.35)] bg-[rgba(239,68,68,0.06)] p-5">
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-semibold uppercase tracking-wider text-[rgba(239,68,68,0.9)]">
                        Top Loser
                      </div>
                      <div className="grid h-10 w-10 place-items-center rounded-2xl border border-[rgba(239,68,68,0.35)] bg-[rgba(239,68,68,0.10)]">
                        <ArrowDownRight className="h-5 w-5 text-[rgb(239,68,68)]" />
                      </div>
                    </div>
                    <div className="mt-4 text-2xl font-bold">
                      {String(insights.topLoser.ticker).toUpperCase()}
                    </div>
                    <div className="mt-1 text-sm text-muted-foreground">
                      {insights.topLoser.stockName}
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-2">
                      <div className="rounded-2xl border border-border/70 bg-black/20 p-3">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          % Move
                        </div>
                        <div className="mt-1 font-semibold tabular-nums text-[rgb(239,68,68)]">
                          {formatPct(insights.topLoser.pct)}
                        </div>
                      </div>
                      <div className="rounded-2xl border border-border/70 bg-black/20 p-3">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Price
                        </div>
                        <div className="mt-1 font-semibold tabular-nums">
                          {formatGBP(insights.topLoser.price)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </GlassCard>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
