import { useEffect, useMemo, useRef, useState } from "react";
import AppShell from "@/components/AppShell";
import GlassCard from "@/components/GlassCard";
import ToolbarSearch from "@/components/ToolbarSearch";
import PaginationBar from "@/components/PaginationBar";
import MetricPill from "@/components/MetricPill";
import StatusChip from "@/components/StatusChip";
import { useMovers } from "@/hooks/use-movers";
import { RefreshCw, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";

import { AgGridReact } from "ag-grid-react";
import { 
  ModuleRegistry, 
  AllCommunityModule,
  type ColDef,
  type GridApi,
  type GridReadyEvent,
  type RowClickedEvent,
  type ICellRendererParams,
  type ValueFormatterParams,
} from "ag-grid-community";

ModuleRegistry.registerModules([ AllCommunityModule ]);

import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

type Row = {
  id: number;
  ticker: string;
  stockName: string;
  price: string;
  percentageMove: string;
  change: string;
  previousClose: string;
  asOf: string;
  source: string;
};

function parseNum(v: unknown): number {
  if (typeof v === "number") return v;
  if (typeof v === "string") {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }
  return 0;
}

function formatGBP(n: number, withSign?: boolean) {
  const sign = withSign ? (n > 0 ? "+" : n < 0 ? "−" : "") : "";
  const abs = Math.abs(n);
  return `${sign}£${abs.toFixed(2)}`;
}

function formatPct(n: number) {
  const sign = n > 0 ? "+" : n < 0 ? "−" : "";
  return `${sign}${Math.abs(n).toFixed(2)}%`;
}

function formatTimestamp(iso: string) {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  } catch {
    return iso;
  }
}

function PercentMoveCell(p: ICellRendererParams<Row>) {
  const raw = parseNum(p.value);
  const lowerBound = -5;
  const upperBound = 5;

  const neg = raw < 0;
  const pos = raw > 0;

  const maxHalf = 50; // percent of cell width
  const width = pos
    ? Math.min((raw / upperBound) * maxHalf, maxHalf)
    : neg
      ? Math.min((Math.abs(raw) / Math.abs(lowerBound)) * maxHalf, maxHalf)
      : 0;

  const barColor = pos ? "rgba(16,185,129,0.30)" : neg ? "rgba(239,68,68,0.30)" : "transparent";
  const textColor = pos ? "rgb(16,185,129)" : neg ? "rgb(239,68,68)" : "rgb(107,114,128)";

  return (
    <div className="relative h-full w-full">
      {/* midpoint */}
      <div className="absolute left-1/2 top-1/2 h-5 w-px -translate-x-1/2 -translate-y-1/2 bg-border/70" />
      {/* bar */}
      {width > 0 ? (
        <div
          className="absolute top-1/2 h-5 -translate-y-1/2 rounded-md"
          style={{
            background: barColor,
            left: pos ? "50%" : undefined,
            right: neg ? "50%" : undefined,
            width: `${width}%`,
          }}
        />
      ) : null}

      <div className="relative z-10 flex h-full items-center justify-end pr-1 font-semibold tabular-nums">
        <span style={{ color: textColor }}>{formatPct(raw)}</span>
      </div>
    </div>
  );
}

export default function MoversPage() {
  const [limit] = useState<number>(50);

  const { data, isLoading, error, refetch, isFetching } = useMovers({ limit });

  const [tickerFilter, setTickerFilter] = useState("");
  const [nameFilter, setNameFilter] = useState("");

  const [page, setPage] = useState(1);
  const pageSize = 25;

  const [selected, setSelected] = useState<Row | null>(null);

  const gridApiRef = useRef<GridApi | null>(null);

  const rows: Row[] = useMemo(() => {
    const stocks = data?.stocks ?? [];

    // Default sort by ABS(% move) desc
    const sorted = [...stocks].sort((a, b) => {
      const av = Math.abs(parseNum(a.percentageMove));
      const bv = Math.abs(parseNum(b.percentageMove));
      return bv - av;
    });

    // text filters (ticker + stockName only)
    const t = tickerFilter.trim().toLowerCase();
    const n = nameFilter.trim().toLowerCase();
    const filtered = sorted.filter((r) => {
      const okT = t ? String(r.ticker ?? "").toLowerCase().includes(t) : true;
      const okN = n ? String(r.stockName ?? "").toLowerCase().includes(n) : true;
      return okT && okN;
    });

    return filtered as Row[];
  }, [data?.stocks, tickerFilter, nameFilter]);

  const total = rows.length;

  const pagedRows = useMemo(() => {
    const startIdx = (page - 1) * pageSize;
    return rows.slice(startIdx, startIdx + pageSize);
  }, [rows, page, pageSize]);

  useEffect(() => {
    // reset to page 1 when filters change
    setPage(1);
  }, [tickerFilter, nameFilter]);

  useEffect(() => {
    // if page out of range after data/filter changes
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    if (page > totalPages) setPage(totalPages);
  }, [total, page, pageSize]);

  const columnDefs = useMemo<ColDef<Row>[]>(() => {
    const common = {
      sortable: true,
      resizable: false,
      suppressMovable: true,
    } satisfies Partial<ColDef<Row>>;

    const numberClass = "text-right tabular-nums";
    const leftClass = "text-left";

    return [
      {
        ...common,
        headerName: "Ticker",
        field: "ticker",
        width: 100,
        filter: "agTextColumnFilter",
        cellClass: leftClass,
        valueFormatter: (p: ValueFormatterParams<Row, unknown>) =>
          String(p.value ?? "").toUpperCase(),
      },
      {
        ...common,
        headerName: "Stock Name",
        field: "stockName",
        width: 250,
        filter: "agTextColumnFilter",
        cellClass: leftClass,
      },
      {
        ...common,
        headerName: "Price",
        field: "price",
        width: 120,
        filter: false,
        cellClass: numberClass,
        valueFormatter: (p: ValueFormatterParams<Row, unknown>) => {
          const n = parseNum(p.value);
          return `£${n.toFixed(2)}`;
        },
      },
      {
        ...common,
        headerName: "% Move",
        field: "percentageMove",
        width: 120,
        filter: false,
        cellRenderer: PercentMoveCell,
      },
      {
        ...common,
        headerName: "Change",
        field: "change",
        width: 120,
        filter: false,
        cellClass: numberClass,
        valueFormatter: (p: ValueFormatterParams<Row, unknown>) => {
          const n = parseNum(p.value);
          return formatGBP(n, true);
        },
      },
    ];
  }, []);

  const defaultColDef = useMemo<ColDef<Row>>(
    () => ({
      sortable: true,
      filter: false,
      flex: 0,
      minWidth: 80,
    }),
    []
  );

  const onGridReady = (e: GridReadyEvent<Row>) => {
    gridApiRef.current = e.api;
  };

  const onRowClicked = (e: RowClickedEvent<Row>) => {
    setSelected(e.data ?? null);
  };

  const rightSlot = (
    <div className="flex flex-wrap items-center justify-end gap-2">
      {data?.meta ? <StatusChip status={data.meta.marketStatus} /> : null}
      <button
        type="button"
        onClick={() => refetch()}
        data-testid="refresh-button"
        className={cn(
          "group inline-flex items-center gap-2 rounded-2xl border px-4 py-2 text-sm font-semibold",
          "bg-gradient-to-br from-primary/85 via-primary/70 to-accent/50 text-primary-foreground border-primary/30",
          "shadow-lg shadow-primary/20 transition-all duration-200",
          "hover:-translate-y-0.5 hover:shadow-xl hover:shadow-primary/25",
          "active:translate-y-0 active:shadow-md",
          "focus:outline-none focus:ring-4 focus:ring-ring/25 focus:border-ring",
          "disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none"
        )}
        disabled={isFetching}
      >
        <RefreshCw className={cn("h-4 w-4 transition-transform duration-300", isFetching ? "animate-spin" : "group-hover:-rotate-12")} />
        {isFetching ? "Refreshing…" : "Refresh"}
      </button>
    </div>
  );

  return (
    <AppShell
      title="LSE Top 50 Movers"
      subtitle={
        <div className="flex flex-col gap-1">
          <div className="text-muted-foreground">
            A clean, high-signal view of the biggest percentage movers — tuned for speed.
          </div>
          <div className="text-xs text-muted-foreground/80">
            Default ranking uses <span className="font-semibold text-foreground/90">absolute % move</span>{" "}
            to surface both gainers and losers.
          </div>
        </div>
      }
      rightSlot={rightSlot}
    >
      <div className="animate-in-soft">
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* Left: Controls */}
          <div className="lg:col-span-4 xl:col-span-3">
            <GlassCard className="h-full">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-xl">Filters & Signal</h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Text filters apply to <span className="font-semibold text-foreground/90">Ticker</span> and{" "}
                    <span className="font-semibold text-foreground/90">Stock Name</span>.
                  </p>
                </div>
              </div>

              <div className="mt-5 space-y-4">
                <ToolbarSearch
                  label="Ticker"
                  value={tickerFilter}
                  onChange={setTickerFilter}
                  placeholder="e.g., VOD"
                  testId="filter-ticker"
                />

                <ToolbarSearch
                  label="Stock Name"
                  value={nameFilter}
                  onChange={setNameFilter}
                  placeholder="e.g., Barclays"
                  testId="filter-name"
                />

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-1">
                  <MetricPill
                    data-testid="metric-total"
                    label="Results"
                    value={`${total}`}
                    tone="neutral"
                  />
                  <MetricPill
                    data-testid="metric-last-updated"
                    label="Last Updated"
                    value={data?.meta?.lastUpdated ? formatTimestamp(data.meta.lastUpdated) : "—"}
                    tone="neutral"
                  />
                </div>

                <div className="rounded-2xl border border-border/70 bg-card/25 p-4">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Selected
                  </div>
                  {selected ? (
                    <div className="mt-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-lg font-bold">
                          {String(selected.ticker).toUpperCase()}
                        </div>
                        <div className="rounded-full border border-border/70 bg-muted/25 px-2.5 py-1 text-xs font-semibold text-muted-foreground">
                          ID {selected.id}
                        </div>
                      </div>
                      <div className="mt-1 text-sm text-muted-foreground">
                        {selected.stockName}
                      </div>

                      <div className="mt-4 grid grid-cols-2 gap-2">
                        <div className="rounded-2xl border border-border/70 bg-muted/20 p-3">
                          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            Price
                          </div>
                          <div className="mt-1 text-sm font-semibold tabular-nums">
                            £{parseNum(selected.price).toFixed(2)}
                          </div>
                        </div>
                        <div className="rounded-2xl border border-border/70 bg-muted/20 p-3">
                          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            Change
                          </div>
                          <div className="mt-1 text-sm font-semibold tabular-nums">
                            {formatGBP(parseNum(selected.change), true)}
                          </div>
                        </div>
                        <div className="rounded-2xl border border-border/70 bg-muted/20 p-3">
                          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            % Move
                          </div>
                          <div
                            className={cn(
                              "mt-1 text-sm font-semibold tabular-nums",
                              parseNum(selected.percentageMove) > 0 && "text-[rgb(16,185,129)]",
                              parseNum(selected.percentageMove) < 0 && "text-[rgb(239,68,68)]",
                              parseNum(selected.percentageMove) === 0 && "text-[rgb(107,114,128)]"
                            )}
                          >
                            {formatPct(parseNum(selected.percentageMove))}
                          </div>
                        </div>
                        <div className="rounded-2xl border border-border/70 bg-muted/20 p-3">
                          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            Prev Close
                          </div>
                          <div className="mt-1 text-sm font-semibold tabular-nums">
                            £{parseNum(selected.previousClose).toFixed(2)}
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 text-xs text-muted-foreground">
                        As of{" "}
                        <span className="font-semibold text-foreground/90">
                          {formatTimestamp(selected.asOf)}
                        </span>{" "}
                        • source{" "}
                        <span className="font-semibold text-foreground/90">
                          {selected.source}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-3 rounded-2xl border border-border/70 bg-muted/15 p-4 text-sm text-muted-foreground">
                      Click a row to inspect details.
                    </div>
                  )}
                </div>
              </div>
            </GlassCard>
          </div>

          {/* Right: Grid */}
          <div className="lg:col-span-8 xl:col-span-9">
            <GlassCard className="h-[70vh] min-h-[540px] p-3 sm:p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h2 className="text-xl">Movers Grid</h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Sticky header, single-row selection, and crisp numeric alignment.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="rounded-2xl border border-border/70 bg-muted/20 px-3 py-2 text-xs text-muted-foreground">
                    Pagination: <span className="font-semibold text-foreground/90">25</span>/page
                  </div>
                  <div className="rounded-2xl border border-border/70 bg-muted/20 px-3 py-2 text-xs text-muted-foreground">
                    Columns: <span className="font-semibold text-foreground/90">5</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 h-[calc(100%-110px)] min-h-[380px]" data-testid="grid-container">
                {isLoading ? (
                  <div className="grid h-full place-items-center rounded-3xl border border-border/70 bg-card/25">
                    <div className="flex flex-col items-center gap-3">
                      <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-primary/70 to-accent/50 shadow-lg shadow-primary/20 animate-pulse" />
                      <div className="text-sm font-semibold">Loading movers…</div>
                      <div className="text-xs text-muted-foreground">
                        Pulling latest snapshot.
                      </div>
                    </div>
                  </div>
                ) : error ? (
                  <div className="grid h-full place-items-center rounded-3xl border border-destructive/40 bg-[rgba(239,68,68,0.07)]">
                    <div className="max-w-md px-6 text-center">
                      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl border border-destructive/40 bg-[rgba(239,68,68,0.10)]">
                        <ShieldAlert className="h-7 w-7 text-destructive" />
                      </div>
                      <div className="mt-3 text-lg font-bold">Couldn’t load movers</div>
                      <div className="mt-1 text-sm text-muted-foreground">
                        {String((error as Error).message ?? "Unknown error")}
                      </div>
                      <button
                        type="button"
                        onClick={() => refetch()}
                        data-testid="error-retry"
                        className={cn(
                          "mt-5 inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold",
                          "bg-gradient-to-br from-destructive/90 to-destructive/70 text-destructive-foreground",
                          "shadow-lg shadow-black/25 transition-all duration-200",
                          "hover:-translate-y-0.5 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-destructive/20"
                        )}
                      >
                        Retry
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="ag-theme-alpine h-full w-full">
                    <AgGridReact
                      onGridReady={onGridReady}
                      rowData={pagedRows}
                      columnDefs={columnDefs}
                      defaultColDef={defaultColDef}
                      suppressCellFocus={false}
                      rowSelection="single"
                      onRowClicked={onRowClicked}
                      headerHeight={46}
                      rowHeight={44}
                      suppressRowClickSelection={false}
                      domLayout="normal"
                    />
                  </div>
                )}
              </div>

              <div className="mt-4" data-testid="pagination-controls">
                <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} />
              </div>
            </GlassCard>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
