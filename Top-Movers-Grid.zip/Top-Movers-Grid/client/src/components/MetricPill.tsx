import React from "react";
import { cn } from "@/lib/utils";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";

export default function MetricPill({
  label,
  value,
  tone = "neutral",
  "data-testid": dataTestId,
}: {
  label: string;
  value: string;
  tone?: "positive" | "negative" | "neutral";
  "data-testid"?: string;
}) {
  const Icon = tone === "positive" ? ArrowUpRight : tone === "negative" ? ArrowDownRight : Minus;

  return (
    <div
      data-testid={dataTestId}
      className={cn(
        "group flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-semibold",
        "bg-muted/25 border-border/70",
        "transition-all duration-200 hover:bg-muted/35 hover:border-border"
      )}
    >
      <span
        className={cn(
          "grid h-7 w-7 place-items-center rounded-xl border",
          "bg-card/30 border-border/70",
          tone === "positive" && "text-[rgb(16,185,129)]",
          tone === "negative" && "text-[rgb(239,68,68)]",
          tone === "neutral" && "text-muted-foreground"
        )}
      >
        <Icon className="h-4 w-4" />
      </span>
      <div className="min-w-0">
        <div className="text-muted-foreground">{label}</div>
        <div
          className={cn(
            "mt-0.5 truncate text-sm",
            tone === "positive" && "text-[rgb(16,185,129)]",
            tone === "negative" && "text-[rgb(239,68,68)]"
          )}
        >
          {value}
        </div>
      </div>
    </div>
  );
}
