import React from "react";
import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ToolbarSearch({
  label,
  value,
  onChange,
  placeholder,
  testId,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  testId: string;
}) {
  return (
    <div className="w-full">
      <div className="mb-2 flex items-center justify-between">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        {value ? (
          <button
            type="button"
            data-testid={`${testId}-clear`}
            onClick={() => onChange("")}
            className={cn(
              "inline-flex items-center gap-1 rounded-full border border-border/70 bg-card/30 px-2 py-1 text-[11px] font-semibold text-muted-foreground",
              "transition-all duration-200 hover:bg-card/50 hover:text-foreground focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring"
            )}
          >
            <X className="h-3.5 w-3.5" />
            Clear
          </button>
        ) : null}
      </div>

      <div
        className={cn(
          "group flex items-center gap-2 rounded-2xl border border-border/70 bg-card/30 px-3 py-2",
          "shadow-sm shadow-black/20 transition-all duration-200",
          "focus-within:border-ring focus-within:ring-4 focus-within:ring-ring/20 hover:bg-card/45"
        )}
      >
        <Search className="h-4 w-4 text-muted-foreground transition-colors group-focus-within:text-foreground" />
        <input
          data-testid={testId}
          type="search"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
        />
      </div>
    </div>
  );
}
