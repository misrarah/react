import React from "react";
import { cn } from "@/lib/utils";
import { Clock, Moon, Sun, Sunset } from "lucide-react";

export default function StatusChip({
  status,
}: {
  status: "open" | "closed" | "pre-market" | "after-hours";
}) {
  const cfg = (() => {
    switch (status) {
      case "open":
        return { label: "Market Open", icon: Sun, cls: "text-[rgb(16,185,129)] border-[rgba(16,185,129,0.35)] bg-[rgba(16,185,129,0.08)]" };
      case "closed":
        return { label: "Market Closed", icon: Moon, cls: "text-muted-foreground border-border/70 bg-muted/25" };
      case "pre-market":
        return { label: "Pre‑Market", icon: Clock, cls: "text-[rgb(56,189,248)] border-[rgba(56,189,248,0.35)] bg-[rgba(56,189,248,0.08)]" };
      case "after-hours":
        return { label: "After Hours", icon: Sunset, cls: "text-[rgb(250,204,21)] border-[rgba(250,204,21,0.35)] bg-[rgba(250,204,21,0.08)]" };
    }
  })();

  const Icon = cfg.icon;

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold",
        "shadow-sm shadow-black/20",
        cfg.cls
      )}
      data-testid="market-status"
    >
      <span className="grid h-6 w-6 place-items-center rounded-full bg-black/20 ring-1 ring-white/10">
        <Icon className="h-3.5 w-3.5" />
      </span>
      <span>{cfg.label}</span>
    </div>
  );
}
