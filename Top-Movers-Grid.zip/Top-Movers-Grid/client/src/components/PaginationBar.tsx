import React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

function IconButton({
  disabled,
  onClick,
  children,
  testId,
  label,
}: {
  disabled?: boolean;
  onClick: () => void;
  children: React.ReactNode;
  testId: string;
  label: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      data-testid={testId}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "inline-flex h-10 w-10 items-center justify-center rounded-2xl border",
        "bg-card/35 border-border/70 text-foreground",
        "shadow-sm shadow-black/20 transition-all duration-200",
        "hover:-translate-y-0.5 hover:bg-card/55 hover:shadow-lg hover:shadow-black/30",
        "active:translate-y-0 active:shadow-md",
        "focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring",
        "disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
      )}
    >
      {children}
    </button>
  );
}

export default function PaginationBar({
  page,
  pageSize,
  total,
  onPageChange,
}: {
  page: number; // 1-based
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
}) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const clampedPage = Math.min(Math.max(page, 1), totalPages);

  const start = total === 0 ? 0 : (clampedPage - 1) * pageSize + 1;
  const end = total === 0 ? 0 : Math.min(total, clampedPage * pageSize);

  const pagesToShow = (() => {
    const windowSize = 5;
    let from = Math.max(1, clampedPage - Math.floor(windowSize / 2));
    let to = Math.min(totalPages, from + windowSize - 1);
    from = Math.max(1, to - windowSize + 1);
    const arr: number[] = [];
    for (let i = from; i <= to; i++) arr.push(i);
    return arr;
  })();

  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="text-sm text-muted-foreground" data-testid="pagination-summary">
        <span className="font-semibold text-foreground/90">Showing</span>{" "}
        <span className="tabular-nums">{start}</span>–<span className="tabular-nums">{end}</span>{" "}
        <span className="text-muted-foreground">of</span>{" "}
        <span className="tabular-nums font-semibold text-foreground/90">{total}</span>{" "}
        <span className="text-muted-foreground">entries</span>
      </div>

      <div className="flex items-center gap-2">
        <IconButton
          testId="pagination-prev"
          label="Previous page"
          disabled={clampedPage <= 1}
          onClick={() => onPageChange(clampedPage - 1)}
        >
          <ChevronLeft className="h-4 w-4" />
        </IconButton>

        <div className="flex items-center gap-2">
          {pagesToShow.map((p) => {
            const active = p === clampedPage;
            return (
              <button
                key={p}
                type="button"
                data-testid={`pagination-page-${p}`}
                onClick={() => onPageChange(p)}
                className={cn(
                  "h-10 min-w-10 rounded-2xl border px-3 text-sm font-semibold tabular-nums",
                  "transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring",
                  active
                    ? "bg-gradient-to-br from-primary/90 to-primary/60 text-primary-foreground border-primary/40 shadow-lg shadow-primary/20"
                    : "bg-card/35 border-border/70 text-foreground hover:bg-card/55 hover:-translate-y-0.5"
                )}
              >
                {p}
              </button>
            );
          })}
        </div>

        <IconButton
          testId="pagination-next"
          label="Next page"
          disabled={clampedPage >= totalPages}
          onClick={() => onPageChange(clampedPage + 1)}
        >
          <ChevronRight className="h-4 w-4" />
        </IconButton>
      </div>
    </div>
  );
}
