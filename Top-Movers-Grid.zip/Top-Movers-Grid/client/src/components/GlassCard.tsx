import React from "react";
import { cn } from "@/lib/utils";

export default function GlassCard({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section
      className={cn(
        "glass grain-overlay rounded-3xl p-4 sm:p-6",
        "transition-all duration-300 hover:shadow-[0_30px_90px_rgba(0,0,0,0.5)]",
        className
      )}
    >
      {children}
    </section>
  );
}
