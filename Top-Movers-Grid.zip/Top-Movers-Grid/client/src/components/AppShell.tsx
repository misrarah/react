import React from "react";
import { Link, useLocation } from "wouter";
import { BarChart3, Grid3X3, Info } from "lucide-react";
import { cn } from "@/lib/utils";

function BrandMark() {
  return (
    <div className="relative">
      <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-primary/90 via-primary/70 to-accent/70 shadow-lg shadow-primary/20 ring-1 ring-white/10" />
      <div className="pointer-events-none absolute inset-0 rounded-2xl grain-overlay" />
      <div className="absolute inset-0 grid place-items-center">
        <div className="h-4 w-4 rounded-full bg-black/40 ring-1 ring-white/10" />
      </div>
    </div>
  );
}

export default function AppShell({
  title,
  subtitle,
  rightSlot,
  children,
}: {
  title: string;
  subtitle?: React.ReactNode;
  rightSlot?: React.ReactNode;
  children: React.ReactNode;
}) {
  const [location] = useLocation();
  const nav = [
    { href: "/", label: "Movers Grid", icon: Grid3X3 },
    { href: "/insights", label: "Insights", icon: BarChart3 },
    { href: "/about", label: "About", icon: Info },
  ];

  return (
    <div className="min-h-screen bg-mesh">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <header className="pt-6 sm:pt-8">
          <div className="glass grain-overlay rounded-3xl px-4 py-4 sm:px-6 sm:py-5">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-start gap-4">
                <BrandMark />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                    <h1 className="text-balance text-2xl sm:text-3xl md:text-4xl">
                      {title}
                    </h1>
                    <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1 text-xs font-semibold tracking-wide text-muted-foreground">
                      LSE • Terminal View
                    </span>
                  </div>
                  {subtitle ? (
                    <div className="mt-2 text-sm text-muted-foreground">{subtitle}</div>
                  ) : null}
                </div>
              </div>

              <div className="flex items-center justify-between gap-3 md:justify-end">
                {rightSlot}
              </div>
            </div>

            <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <nav className="flex flex-wrap items-center gap-2">
                {nav.map((item) => {
                  const Icon = item.icon;
                  const active = item.href === "/" ? location === "/" : location.startsWith(item.href);
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "group inline-flex items-center gap-2 rounded-2xl px-3 py-2 text-sm font-semibold transition-all duration-200",
                        "border border-border/70 bg-card/30 hover:bg-card/45 hover:shadow-lg hover:shadow-black/20",
                        "focus:outline-none focus:ring-4 focus:ring-ring/20 focus:border-ring",
                        active
                          ? "text-foreground ring-1 ring-primary/25 shadow-md shadow-primary/10"
                          : "text-muted-foreground"
                      )}
                    >
                      <Icon className={cn("h-4 w-4 transition-transform duration-200", active ? "" : "group-hover:-translate-y-0.5")} />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </nav>

              <div className="flex items-center justify-between gap-2">
                <div className="hidden sm:flex items-center gap-2 rounded-2xl border border-border/70 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
                  <span className="inline-block h-2 w-2 rounded-full bg-primary/80 shadow-[0_0_0_4px_rgba(16,185,129,0.08)]" />
                  <span className="font-medium">Data refresh on demand</span>
                </div>

                <div className="text-xs text-muted-foreground sm:hidden">
                  Swipe horizontally if needed
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="pb-10 pt-6 sm:pt-8">{children}</main>

        <footer className="pb-10">
          <div className="mx-auto max-w-7xl">
            <div className="flex flex-col items-start justify-between gap-3 rounded-3xl border border-border/60 bg-card/25 px-5 py-4 text-xs text-muted-foreground sm:flex-row sm:items-center">
              <div>
                <span className="font-semibold text-foreground/90">LSE Top Movers Grid</span>
                <span className="mx-2 text-muted-foreground/60">•</span>
                <span>Built for speed, clarity, and signal.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded-full border border-border/60 bg-muted/30 px-2.5 py-1">
                  Dark mode professional
                </span>
                <span className="rounded-full border border-border/60 bg-muted/30 px-2.5 py-1">
                  AG Grid
                </span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
