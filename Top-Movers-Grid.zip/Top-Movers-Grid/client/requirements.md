## Packages
(none needed)

## Notes
AG Grid is already installed (ag-grid-react, ag-grid-community).
Frontend expects GET /api/movers with optional query params: limit, asOf.
API numeric fields arrive as strings (from Postgres numeric). UI parses/format defensively.
Dark mode aesthetic is default (no theme toggle required).
