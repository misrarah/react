import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.movers.list.path, async (req, res) => {
    const limitRaw = req.query.limit;
    const limit =
      typeof limitRaw === "string" && limitRaw.trim().length > 0
        ? Math.max(1, Math.min(200, Number(limitRaw)))
        : 50;

    await storage.seedMoversIfEmpty();

    const [stocks, meta] = await Promise.all([
      storage.getTopMovers(limit),
      storage.getMoversMeta(limit),
    ]);

    res.json({ meta, stocks });
  });

  return httpServer;
}
