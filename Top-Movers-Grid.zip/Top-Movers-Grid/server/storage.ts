import { db } from "./db";
import {
  stockMovers,
  type CreateStockMoverRequest,
  type MoversResponse,
  type StockMoverResponse,
} from "@shared/schema";
import { desc, eq, sql } from "drizzle-orm";

export interface IStorage {
  getTopMovers(limit: number): Promise<StockMoverResponse[]>;
  getMoversMeta(limit: number): Promise<MoversResponse["meta"]>;
  seedMoversIfEmpty(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getTopMovers(limit: number): Promise<StockMoverResponse[]> {
    // Rank by absolute % move (desc). percentageMove is NUMERIC in DB.
    return await db
      .select()
      .from(stockMovers)
      .orderBy(desc(sql`abs(${stockMovers.percentageMove})`))
      .limit(limit);
  }

  async getMoversMeta(limit: number): Promise<MoversResponse["meta"]> {
    const [{ total }] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(stockMovers);

    const [latest] = await db
      .select({ asOf: stockMovers.asOf })
      .from(stockMovers)
      .orderBy(desc(stockMovers.asOf))
      .limit(1);

    const lastUpdated = (latest?.asOf ?? new Date()).toISOString();

    return {
      lastUpdated,
      marketStatus: "closed",
      total: total ?? 0,
    };
  }

  async seedMoversIfEmpty(): Promise<void> {
    const [{ total }] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(stockMovers);

    if ((total ?? 0) > 0) return;

    const asOf = new Date();

    const seed: CreateStockMoverRequest[] = [
      {
        ticker: "BARC.L",
        stockName: "Barclays PLC",
        price: "162.34",
        percentageMove: "4.87",
        change: "7.54",
        previousClose: "154.80",
        asOf,
        source: "seed",
      },
      {
        ticker: "BP.L",
        stockName: "BP p.l.c.",
        price: "471.20",
        percentageMove: "-3.12",
        change: "-15.18",
        previousClose: "486.38",
        asOf,
        source: "seed",
      },
      {
        ticker: "SHEL.L",
        stockName: "Shell plc",
        price: "2578.50",
        percentageMove: "2.09",
        change: "52.80",
        previousClose: "2525.70",
        asOf,
        source: "seed",
      },
      {
        ticker: "HSBA.L",
        stockName: "HSBC Holdings plc",
        price: "678.10",
        percentageMove: "-4.51",
        change: "-32.10",
        previousClose: "710.20",
        asOf,
        source: "seed",
      },
      {
        ticker: "AZN.L",
        stockName: "AstraZeneca PLC",
        price: "10425.00",
        percentageMove: "1.34",
        change: "137.80",
        previousClose: "10287.20",
        asOf,
        source: "seed",
      },
      {
        ticker: "VOD.L",
        stockName: "Vodafone Group Plc",
        price: "68.42",
        percentageMove: "-2.77",
        change: "-1.95",
        previousClose: "70.37",
        asOf,
        source: "seed",
      },
    ];

    // Expand to a fuller, realistic list (deterministic pseudo-sample)
    const more = [
      ["RR.L", "Rolls-Royce Holdings plc"],
      ["LLOY.L", "Lloyds Banking Group plc"],
      ["GLEN.L", "Glencore plc"],
      ["PRU.L", "Prudential plc"],
      ["DGE.L", "Diageo plc"],
      ["ULVR.L", "Unilever PLC"],
      ["NG.L", "National Grid plc"],
      ["RIO.L", "Rio Tinto Group"],
      ["BATS.L", "British American Tobacco p.l.c."],
      ["GSK.L", "GSK plc"],
      ["BA.L", "BAE Systems plc"],
      ["REL.L", "RELX PLC"],
      ["AAL.L", "Anglo American plc"],
      ["BT.A.L", "BT Group plc"],
      ["EXPN.L", "Experian plc"],
      ["HLMA.L", "Halma plc"],
      ["IMB.L", "Imperial Brands PLC"],
      ["JD.L", "JD Sports Fashion Plc"],
      ["KGF.L", "Kingfisher plc"],
      ["MKS.L", "Marks and Spencer Group plc"],
      ["SGE.L", "Sage Group plc"],
      ["SMT.L", "Scottish Mortgage Investment Trust"],
      ["STAN.L", "Standard Chartered PLC"],
      ["WTB.L", "Whitbread PLC"],
      ["III.L", "3i Group plc"],
      ["SBRY.L", "J Sainsbury plc"],
      ["TSCO.L", "Tesco PLC"],
      ["CPG.L", "Compass Group PLC"],
      ["RKT.L", "Reckitt Benckiser Group plc"],
      ["CNA.L", "Centrica plc"],
      ["ANTO.L", "Antofagasta plc"],
      ["BNZL.L", "Bunzl plc"],
      ["CRH.L", "CRH plc"],
      ["HL.L", "Hargreaves Lansdown plc"],
      ["ITRK.L", "Intertek Group plc"],
      ["LAND.L", "Land Securities Group PLC"],
      ["LGEN.L", "Legal & General Group Plc"],
      ["MNG.L", "M&G plc"],
      ["PHNX.L", "Phoenix Group Holdings plc"],
      ["RS1.L", "RS Group plc"],
      ["SDR.L", "Schroders plc"],
      ["SSE.L", "SSE plc"],
      ["SVT.L", "Severn Trent Plc"],
      ["UU.L", "United Utilities Group PLC"],
      ["WEIR.L", "The Weir Group PLC"],
    ] as const;

    const seeded: CreateStockMoverRequest[] = [...seed];
    for (let i = 0; i < more.length && seeded.length < 50; i++) {
      const [ticker, stockName] = more[i];
      const base = 50 + i * 7.13;
      const price = (base * (i % 2 === 0 ? 3.21 : 1.47)).toFixed(2);
      const pct = (((i % 7) - 3) * 1.13 + (i % 3) * 0.27).toFixed(2);
      const percentageMove = String(pct);
      const previousClose = (Number(price) / (1 + Number(percentageMove) / 100)).toFixed(2);
      const change = (Number(price) - Number(previousClose)).toFixed(2);

      seeded.push({
        ticker,
        stockName,
        price,
        percentageMove,
        change,
        previousClose,
        asOf,
        source: "seed",
      });
    }

    await db.insert(stockMovers).values(seeded);
  }
}

export const storage = new DatabaseStorage();
