import { z } from "zod";
import { insertStockMoverSchema, stockMovers } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

const stockMoverResponseSchema = z.custom<typeof stockMovers.$inferSelect>();

export const api = {
  movers: {
    list: {
      method: "GET" as const,
      path: "/api/movers" as const,
      input: z
        .object({
          limit: z.coerce.number().int().min(1).max(200).optional(),
          asOf: z.string().optional(),
        })
        .optional(),
      responses: {
        200: z.object({
          meta: z.object({
            lastUpdated: z.string(),
            marketStatus: z.enum(["open", "closed", "pre-market", "after-hours"]),
            total: z.number().int().nonnegative(),
          }),
          stocks: z.array(stockMoverResponseSchema),
        }),
      },
    },
  },
};

export function buildUrl(
  path: string,
  params?: Record<string, string | number>
): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type MoversListInput = z.infer<typeof api.movers.list.input>;
export type MoversResponse = z.infer<typeof api.movers.list.responses[200]>;
export type ValidationError = z.infer<typeof errorSchemas.validation>;
export type NotFoundError = z.infer<typeof errorSchemas.notFound>;
export type InternalError = z.infer<typeof errorSchemas.internal>;
