import { pgTable, serial, text, numeric, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ============================
// TABLES
// ============================

export const stockMovers = pgTable(
  "stock_movers",
  {
    id: serial("id").primaryKey(),
    ticker: text("ticker").notNull(),
    stockName: text("stock_name").notNull(),
    price: numeric("price", { precision: 18, scale: 4 }).notNull(),
    percentageMove: numeric("percentage_move", { precision: 10, scale: 4 }).notNull(),
    change: numeric("change", { precision: 18, scale: 4 }).notNull(),
    previousClose: numeric("previous_close", { precision: 18, scale: 4 }).notNull(),
    asOf: timestamp("as_of", { withTimezone: true }).notNull(),
    source: text("source").notNull().default("seed"),
  },
  (t) => ({
    tickerIdx: index("stock_movers_ticker_idx").on(t.ticker),
    asOfIdx: index("stock_movers_as_of_idx").on(t.asOf),
  })
);

// ============================
// BASE SCHEMAS
// ============================

export const insertStockMoverSchema = createInsertSchema(stockMovers).omit({
  id: true,
});

// ============================
// EXPLICIT API CONTRACT TYPES
// ============================

export type StockMover = typeof stockMovers.$inferSelect;
export type InsertStockMover = z.infer<typeof insertStockMoverSchema>;

export type CreateStockMoverRequest = InsertStockMover;
export type UpdateStockMoverRequest = Partial<InsertStockMover>;

export type StockMoverResponse = StockMover;
export type StockMoversListResponse = StockMover[];

export type MarketStatus = "open" | "closed" | "pre-market" | "after-hours";

export interface MoversQueryParams {
  limit?: number;
  asOf?: string;
}

export interface MoversMetaResponse {
  lastUpdated: string;
  marketStatus: MarketStatus;
  total: number;
}

export interface MoversResponse {
  meta: MoversMetaResponse;
  stocks: StockMoverResponse[];
}
